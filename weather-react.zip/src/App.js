import React, { useState } from "react";

const api = {
  key: "17ff7f7e26755177c1f22e435024bdbd",
  base: "https://api.openweathermap.org/data/2.5/",
};

function App() {
  const [query, setQuery] = useState('');
  const [weather, setWeather] = useState('{}');

  const search = evt => {
    if (evt.key === "Enter") {
      fetch(`${api.base}weather?q=${query}&units=metric&APPID=${api.key}`)
        .then(res => res.json())
        .then(result => {
          setWeather(result);
          setQuery('');
        });
    }
  }

  const searchOnBtn = (e) => {
    e.preventDefault();
    fetch(`${api.base}weather?q=${query}&units=metric&APPID=${api.key}`)
      .then(res => res.json())
      .then(result => {
        setWeather(result);
        setQuery('');
      });
  }

  const popularCity = (city) => {
    fetch(`${api.base}weather?q=${city}&units=metric&APPID=${api.key}`)
      .then(res => res.json())
      .then(result => {
        setWeather(result);
        setQuery('');
        console.log(result);
      });
  }

  const belgrade = () => {
    const city = 'Belgrade';
    popularCity(city);
  }

  const nigeria = () => {
    const city = 'Nigeria';
    popularCity(city);
  }

  const madrid = () => {
    const city = 'Madrid';
    popularCity(city);
  }

  const thailand = () => {
    const city = 'Thailand';
    popularCity(city);
  }

  const oslo = () => {
    const city = 'Oslo';
    popularCity(city);
  }

  const budapest = () => {
    const city = 'Budapest';
    popularCity(city);
  }

  const dateBuilder = (d) => {
    let months = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
    let days = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];

    let day = days[d.getDay()];
    let date = d.getDate();
    let month = months[d.getMonth()];
    let year = d.getFullYear();

    return `${day} ${date} ${month} ${year}`
  }

  return (
    <div className={(typeof weather.main != "undefined") ? ((weather.main.temp < 16) ? 'app cold' : 'app') : 'app'}>
      <main>
        <header>
          <p>Weather <span>App</span></p>
        </header>

        <div className="search-box">
          <input
            type="text"
            className="search-bar"
            placeholder="Enter location..."
            onChange={e => setQuery(e.target.value)}
            value={query}
            onKeyPress={search}
          />
          <button type="submit" onClick={searchOnBtn} onChange={e => setQuery(e.target.value)}
            value={query}>Search</button>
        </div>

        {(typeof weather.main != "undefined") ? (
          <div>
            <div className="location-box">
              <div className="location">{weather.name}, {weather.sys.country}</div>
              <div className="date">{dateBuilder(new Date())}</div>
            </div>
            <div className="weather-box">
              <div className="temp">
                {Math.round(weather.main.temp)}°C
              </div>
              <div className="weather">
                <p>{weather.weather[0].main}</p>
                <img className="city-icon" src={`https://openweathermap.org/img/wn/${weather.weather[0].icon}@2x.png`} alt={weather.weather[0].description} />
              </div>
            </div>
          </div>
        ) : ('')}

        <div className="popular">
          <p>Most searched places</p>
          <div className="holder">
            <div className="holder-item">
              <button onClick={belgrade}>Belgrade</button>
            </div>
            <div className="holder-item">
              <button onClick={nigeria}>Nigeria</button>
            </div>
            <div className="holder-item">
              <button onClick={madrid}>Madrid</button>
            </div>
            <div className="holder-item">
              <button onClick={budapest}>Budapest</button>
            </div>
            <div className="holder-item">
              <button onClick={thailand}>Thailand</button>
            </div>
            <div className="holder-item">
              <button onClick={oslo}>Oslo</button>
            </div>
          </div>
        </div>

      </main>
    </div>
  );
}

export default App;
